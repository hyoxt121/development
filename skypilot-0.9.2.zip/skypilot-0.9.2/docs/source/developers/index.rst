Developer Guides
=================

.. toctree::
   :maxdepth: 1

   ../developers/CONTRIBUTING
   Guide: Adding a New Cloud <https://docs.google.com/document/d/1oWox3qb3Kz3wXXSGg9ZJWwijoa99a3PIQUHBR8UgEGs/edit?usp=sharing>
