:orphan:

.. People may hit this old URL; we redirect to the new one instead of 404ing.
.. raw:: html

   <script type="text/javascript">
       window.location.href = "kubernetes/skypilot-and-vanilla-k8s.html";
   </script>
   <meta http-equiv="refresh" content="0; url=kubernetes/skypilot-and-vanilla-k8s.html">
