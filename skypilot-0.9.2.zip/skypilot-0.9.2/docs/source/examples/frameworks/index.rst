Frameworks
====================

.. toctree::
   :maxdepth: 1

   Airflow <airflow>
   DVC <dvc>
   Jupyter <jupyter>
   Kueue <https://github.com/GoogleCloudPlatform/ai-on-gke/tree/main/tutorials-and-examples/skypilot/dws-and-kueue>
   MPI <mpi>
