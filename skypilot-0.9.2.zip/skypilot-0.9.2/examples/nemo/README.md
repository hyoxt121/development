# Nvidia NeMo

This example shows how to launch Nvidia NeMo jobs with SkyPilot.
