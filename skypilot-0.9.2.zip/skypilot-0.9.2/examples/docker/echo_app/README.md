# Echo App

A simple app that ingests a file and writes it out back to a specified path.
