# Ray

This example shows how to launch distributed Ray jobs with SkyPilot.
