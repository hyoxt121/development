# TPU

This example shows how to launch TPU jobs with SkyPilot.

> Note: Some examples may be old. See the `v6e/` files for the latest examples. See also: https://docs.skypilot.co/en/latest/reference/tpu.html.
