# Skylet

Skylet is a subpackage of SkyPilot. It provides utilities to be installed and used by a remote cluster.
