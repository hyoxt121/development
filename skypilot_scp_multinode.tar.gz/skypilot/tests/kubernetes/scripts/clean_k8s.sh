kubectl delete all -l parent=skypilot
