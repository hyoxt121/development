Frameworks
====================

.. toctree::
   :maxdepth: 1

   Airflow <airflow>
   DVC <dvc>
   Jupyter <jupyter>
   GCP DWS/Kueue <https://gke-ai-labs.dev/docs/tutorials/skypilot/resource-management-using-kueue/>
   MPI <mpi>
