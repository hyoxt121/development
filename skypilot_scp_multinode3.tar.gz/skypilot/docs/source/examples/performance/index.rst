AI Performance
====================

.. toctree::
   :maxdepth: 1

   AWS EFA <aws_efa>
   GCP/GKE GPUDirect <gcp_gpu_direct_tcpx>
   Nebius with InfiniBand <nebius_infiniband>
