Frameworks
====================

.. toctree::
   :maxdepth: 1

   Cross-cloud data transfer <https://nebius.com/blog/posts/bulk-object-storage-s3-data-migration-with-skypilot>
   DVC <dvc>
   GCP DWS <https://docs.skypilot.co/en/latest/reservations/reservations.html#gcp-dynamic-workload-scheduler-dws>
   Jupyter <jupyter>
   MLFlow <https://nebius.com/blog/posts/orchestrating-llm-fine-tuning-k8s-skypilot-mlflow>
   MPI <mpi>
