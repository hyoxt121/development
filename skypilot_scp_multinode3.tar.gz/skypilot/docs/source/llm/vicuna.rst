.. People may hit this old URL; we redirect to the new one instead of 404ing.

:orphan:

.. raw:: html

   <script type="text/javascript">
       window.location.href = "../examples/models/vicuna.html";
   </script>
   <meta http-equiv="refresh" content="0; url=../examples/models/vicuna.html">
