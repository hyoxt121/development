Welcome to SkyPilot!
====================


.. raw:: html

   <script type="text/javascript">
       window.location.href = "docs/index.html";
   </script>
   <meta http-equiv="refresh" content="0; url=./docs/index.html">

.. toctree::
   :maxdepth: 1
   :caption: Contents
   :hidden:

   Docs <docs/index>
   Case Studies <https://blog.skypilot.co/case-studies/>
   Blog <https://blog.skypilot.co/>

