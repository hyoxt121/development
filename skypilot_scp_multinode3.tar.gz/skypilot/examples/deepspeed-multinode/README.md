# DeepSpeed

This example shows how to launch a multinode DeepSpeed training job with SkyPilot.

