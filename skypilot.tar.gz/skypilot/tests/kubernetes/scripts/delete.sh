kubectl delete -f skypilot_ssh_k8s_deployment.yaml
