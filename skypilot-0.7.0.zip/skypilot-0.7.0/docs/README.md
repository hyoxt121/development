# Documentation
Sphinx docs based on ReadTheDocs.

## Build
```bash
pip install -r requirements-docs.txt
./build.sh
```

## View
```bash
cd build/html
python -m http.server
```
Open localhost:8000 in your browser.
