import setuptools

setuptools.setup(
    name='sky-callback',
    version='0.1.1-dev0',
    packages=setuptools.find_packages(),
    install_requires=['psutil'],
)
